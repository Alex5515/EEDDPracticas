#ifndef MEDIEXPRESS_H
#define MEDIEXPRESS_H

#include "VDinamico.h"
#include "ListaEnlazada.h"
#include "PaMedicamento.h"
#include "Laboratorio.h"

class MediExpress {
private:
    VDinamico<Pamedicamento> medication;
    ListaEnlazada<Laboratorio> labs;

    void cargarMedicamentos(const std::string& filename);
    void cargarLaboratorios(const std::string& filename);
    void enlazarMedicamentosConLabs();

public:
    MediExpress(const std::string& file_meds, const std::string& file_labs);

    void buscarYMostrarLabsGranada();
    void indicarCuantosLabsJaen();
    void indicarYMostrarLabsMadrid();
    void mostrarLabsSuministranAceites();
    void asignarLabsAMedicamentosSinSuministrador();

    // Función para el trabajo en parejas
    void eliminarLabsBruselas();
};

#endif // MEDIEXPRESS_H
